# KYARAEZ PRO — Landing Page

Files:
- index.html — complete landing page
- style.css — premium editorial/botanical styling
- script.js — sliders, language switcher, floating actions and cart demo

Included:
- KYARAEZ logo + Stories • Business • Creativity
- Soft green / warm brown / ivory palette
- Responsive mobile-first behavior
- 5-image botanical slider
- Professional placeholder biography
- 10-slide Journey / Achievement section
- Stories section
- Small Business showcase
- ID / EN switch
- Floating cart
- Floating Instagram: @zky.a4
- Floating WhatsApp: +6285286707303
- Prefilled WhatsApp text: "haloo kak , aku mau tanya lebih lanjut :)))"
- Newsletter CTA
- Navigation ready for About / Stories / Business / Journey / Contact

Temporary visuals:
Remote Unsplash image URLs are used as temporary botanical imagery. Replace them with your own licensed images for production if desired.

Important:
The biography and 10 Journey entries are intentionally marked as placeholder content until your real profile, achievements and experiences are provided.
