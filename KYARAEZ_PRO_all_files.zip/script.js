const botanical=[
["Fresh Leaves","https://images.unsplash.com/photo-1497250681960-ef046c08a56e?auto=format&fit=crop&w=900&q=85"],
["Soft Green","https://images.unsplash.com/photo-1501004318641-b39e6451bec6?auto=format&fit=crop&w=900&q=85"],
["Wild Bloom","https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=900&q=85"],
["Botanical Light","https://images.unsplash.com/photo-1512428813834-c702c7702b78?auto=format&fit=crop&w=900&q=85"],
["Garden Mood","https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=900&q=85"]
];
const journey=[
["01","THE BEGINNING","Where the idea started.","https://images.unsplash.com/photo-1459411621453-7b03977f4bfc?auto=format&fit=crop&w=900&q=85"],
["02","FIRST CREATIVE PROJECT","An idea became something real.","https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&w=900&q=85"],
["03","FIRST BUSINESS EXPERIENCE","Learning to build from the ground up.","https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=900&q=85"],
["04","A MEANINGFUL COLLABORATION","Creating together.","https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=900&q=85"],
["05","FIRST MILESTONE","A small win worth remembering.","https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=900&q=85"],
["06","GROWING THROUGH COMMUNITY","People make the journey meaningful.","https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=900&q=85"],
["07","A NEW SKILL","Always learning, always evolving.","https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=900&q=85"],
["08","BUILDING THE BRAND","From an idea into an identity.","https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=900&q=85"],
["09","LESSONS ALONG THE WAY","Not every chapter was easy.","https://images.unsplash.com/photo-1506784983877-45594efa4cbe?auto=format&fit=crop&w=900&q=85"],
["10","WHAT’S NEXT","The story is still being written.","https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=900&q=85"]
];

function buildGallery(){
  const el=document.getElementById("botanical");
  el.innerHTML=botanical.map(x=>`<article class="botanical-card"><img loading="lazy" src="${x[1]}" alt="${x[0]}"><span>${x[0]}</span></article>`).join("");
  dots("bDots",botanical.length,el);
}
function buildJourney(){
  const el=document.getElementById("journey");
  el.innerHTML=journey.map(x=>`<article class="journey-card"><div class="journey-image"><img loading="lazy" src="${x[3]}" alt="${x[1]}"></div><div class="journey-info"><small>${x[0]} / JOURNEY</small><h3>${x[1]}</h3><p>${x[2]}</p></div></article>`).join("");
  dots("jDots",journey.length,el);
}
function dots(id,n,track){
  const d=document.getElementById(id);
  for(let i=0;i<n;i++){const b=document.createElement("button");b.className=i===0?"active":"";b.onclick=()=>track.scrollTo({left:track.children[i].offsetLeft,behavior:"smooth"});d.appendChild(b)}
}
function bindScroll(trackId,dotId){
  const t=document.getElementById(trackId),d=document.getElementById(dotId);
  t.addEventListener("scroll",()=>{let best=0,dist=1e9;[...t.children].forEach((c,i)=>{let x=Math.abs(c.offsetLeft-t.scrollLeft);if(x<dist){dist=x;best=i}});[...d.children].forEach((b,i)=>b.classList.toggle("active",i===best))},{passive:true});
  return t;
}
buildGallery();buildJourney();
const bt=bindScroll("botanical","bDots"),jt=bindScroll("journey","jDots");
bPrev.onclick=()=>bt.scrollBy({left:bt.clientWidth*.8,behavior:"smooth"});
bNext.onclick=()=>bt.scrollBy({left:bt.clientWidth*.8,behavior:"smooth"});
jPrev.onclick=()=>jt.scrollBy({left:-jt.clientWidth*.75,behavior:"smooth"});
jNext.onclick=()=>jt.scrollBy({left:jt.clientWidth*.75,behavior:"smooth"});
let timer=setInterval(()=>bt.scrollBy({left:bt.clientWidth*.6,behavior:"smooth"}),4500);
bt.addEventListener("mouseenter",()=>clearInterval(timer));bt.addEventListener("mouseleave",()=>timer=setInterval(()=>bt.scrollBy({left:bt.clientWidth*.6,behavior:"smooth"}),4500));

document.querySelector(".menu").onclick=e=>{document.getElementById("nav").classList.toggle("open")};
document.querySelectorAll("#nav a").forEach(a=>a.onclick=()=>document.getElementById("nav").classList.remove("open"));

const translations={
id:{home:"Home",about:"About",stories:"Stories",business:"Business",journey:"Journey",contact:"Contact"},
en:{home:"Home",about:"About",stories:"Stories",business:"Business",journey:"Journey",contact:"Contact"}
};
document.querySelectorAll(".language button").forEach(b=>b.onclick=()=>{
  document.querySelectorAll(".language button").forEach(x=>x.classList.remove("active"));b.classList.add("active");
  const en=b.dataset.lang==="en";
  document.documentElement.lang=en?"en":"id";
  const nav=document.querySelectorAll("#nav a");
  ["home","about","stories","business","journey","contact"].forEach((k,i)=>nav[i].textContent=translations[en?"en":"id"][k]);
  if(en){
    document.querySelector(".hero .eyebrow").textContent="PERSONAL BLOG • SMALL BUSINESS";
    document.querySelector(".lead").textContent="A little space for personal stories, building a small business, creative notes, and beautiful things worth sharing.";
    document.querySelector(".hero-buttons .primary").textContent="Get to know me";
    document.querySelector(".about-copy blockquote").textContent="“Growing slowly, creating intentionally, and turning little ideas into something meaningful.”";
  }else{
    document.querySelector(".lead").textContent="Ruang kecil untuk cerita personal, proses membangun bisnis, creative notes, dan hal-hal indah yang layak dibagikan.";
    document.querySelector(".hero-buttons .primary").textContent="Kenal lebih dekat";
    document.querySelector(".about-copy blockquote").textContent="“Growing slowly, creating intentionally, and turning little ideas into something meaningful.”";
  }
  localStorage.setItem("kyaraezLang",b.dataset.lang);
});
if(localStorage.getItem("kyaraezLang")==="en")document.querySelector('[data-lang="en"]').click();

document.getElementById("wa").href="https://wa.me/6285286707303?text="+encodeURIComponent("haloo kak , aku mau tanya lebih lanjut :)))");
let count=0;
document.getElementById("cart").onclick=()=>{document.getElementById("toast").textContent="Keranjang masih kosong ♡";document.getElementById("toast").classList.add("show");setTimeout(()=>document.getElementById("toast").classList.remove("show"),2200)};
document.querySelectorAll(".product").forEach(p=>p.onclick=()=>{count++;document.getElementById("count").textContent=count;document.getElementById("toast").textContent=p.querySelector("h3").textContent+" ditambahkan ke keranjang ♡";document.getElementById("toast").classList.add("show");setTimeout(()=>document.getElementById("toast").classList.remove("show"),2200)});
document.getElementById("year").textContent=new Date().getFullYear();
